from enum import StrEnum


class Stone(StrEnum):
    BLACK = "black"
    WHITE = "white"
